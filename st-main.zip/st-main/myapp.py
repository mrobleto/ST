import streamlit as st
st.write("Hello from Streamlit")